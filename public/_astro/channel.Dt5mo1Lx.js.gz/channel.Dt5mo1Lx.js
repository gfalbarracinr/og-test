import{aj as o,ak as n}from"./mermaid.core.D1usf7N0.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
